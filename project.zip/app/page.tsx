import AdventutorialSite from '@/components/adventutorial-site'

export default function Page() {
  return <AdventutorialSite />
}

