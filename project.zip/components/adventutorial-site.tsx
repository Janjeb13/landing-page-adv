import Image from 'next/image'
import Link from 'next/link'
import { ArrowDown, ArrowRight, BookOpen, Brain, Check, GraduationCap, Heart, PhoneCall, Sparkles, Star } from 'lucide-react'

const programs = [
  {
    number: '01',
    icon: GraduationCap,
    title: 'School admission test prep',
    description: 'Prepare with confidence through personalized one-on-one tutoring and focused entrance exam practice.',
    tone: 'lavender',
  },
  {
    number: '02',
    icon: Brain,
    title: 'Toddler development & assessment',
    description: 'Thoughtful support for your toddler’s growth, early skills, and readiness for the next big step.',
    tone: 'lime',
  },
  {
    number: '03',
    icon: BookOpen,
    title: 'One-on-one tutorial services',
    description: 'Personalized lessons that meet your child where they are and help them move forward with confidence.',
    tone: 'blue',
  },
]

function Brand() {
  return (
    <Link href="#home" className="brand" aria-label="Adventutorial Learning Center home">
      <span className="brand-mark"><Sparkles size={19} strokeWidth={2.5} /></span>
      <span className="brand-name">adven<span>tutorial</span><small>LEARNING CENTER</small></span>
    </Link>
  )
}

function Header() {
  return (
    <header className="site-header">
      <div className="header-inner">
        <Brand />
        <nav className="main-nav" aria-label="Main navigation">
          <Link href="#about">Our story</Link>
          <Link href="#programs">Programs</Link>
          <Link href="#why-us">Why Adventutorial</Link>
        </nav>
        <a className="header-cta" href="tel:+639543365987">Let&apos;s talk <ArrowRight size={15} /></a>
        <a className="mobile-cta" href="tel:+639543365987" aria-label="Call Adventutorial Learning Center"><PhoneCall size={19} /></a>
      </div>
    </header>
  )
}

function Hero() {
  return (
    <section className="hero" id="home">
      <div className="hero-wave hero-wave-one" aria-hidden="true" />
      <div className="hero-wave hero-wave-two" aria-hidden="true" />
      <div className="hero-content">
        <div className="eyebrow hero-eyebrow"><span className="eyebrow-dot" /> BIG DREAMS START RIGHT HERE</div>
        <h1>A little help today.<br /><span>For a brighter</span><br />tomorrow.</h1>
        <p className="hero-description">Thoughtful tutoring and early learning support for every stage of your child&apos;s journey.</p>
        <div className="hero-actions">
          <a className="button button-dark" href="#programs">Explore our programs <ArrowRight size={17} /></a>
          <a className="text-link" href="#about">Get to know us <ArrowDown size={15} /></a>
        </div>
        <div className="hero-trust">
          <div className="avatar-stack" aria-hidden="true"><span>A</span><span>M</span><span>J</span><span>+</span></div>
          <div><div className="trust-stars" aria-label="5 out of 5 stars"><Star /><Star /><Star /><Star /><Star /></div><p>A growing community of learners</p></div>
        </div>
      </div>
      <div className="hero-art">
        <div className="photo-frame"><Image src="/adventutorial-learning.png" alt="A tutor helping two young learners study together" fill priority sizes="(max-width: 760px) 92vw, 48vw" className="hero-photo" /></div>
        <div className="photo-caption"><span className="caption-icon"><Heart size={17} fill="currentColor" /></span><span><strong>Learning, made personal</strong><small>One child. One thoughtful plan.</small></span><ArrowRight className="caption-arrow" size={17} /></div>
        <div className="floating-note note-top"><span className="note-sparkle"><Sparkles size={16} /></span><span>Curiosity looks<br />good on you.</span></div>
        <div className="floating-note note-bottom"><span className="note-check"><Check size={16} /></span><span>Small steps.<br />Big confidence.</span></div>
        <div className="image-doodle" aria-hidden="true">✳</div>
      </div>
      <div className="hero-bottom"><span>LEARN AT YOUR OWN PACE</span><span className="bottom-rule" /><span>BUTUAN CITY, PHILIPPINES</span></div>
    </section>
  )
}

function CommunityStrip() {
  return (
    <section className="community-strip" aria-label="Our learner community">
      <div className="community-number">300<span>+</span></div>
      <div className="community-copy"><strong>A community that keeps growing</strong><span>Estimated learners in our growing Adventutorial community</span></div>
      <div className="community-divider" />
      <div className="community-note"><span className="status-dot" /> Rooted in Butuan City <span className="community-note-secondary">&amp; open to every grade level</span></div>
    </section>
  )
}

function About() {
  return (
    <section className="about section-shell" id="about">
      <div className="section-kicker"><span>01</span><span className="kicker-line" /> A LITTLE ABOUT US</div>
      <div className="about-grid">
        <h2>Every learner has<br />their <span>own kind</span> of<br />brilliant.</h2>
        <div className="about-copy"><p>At Adventutorial Learning Center, learning isn&apos;t one-size-fits-all. We meet children with patience, care, and the kind of support that helps confidence grow right alongside knowledge.</p><p>From the first curious questions to big school entrance exams, we&apos;re here for every step.</p><a href="#programs" className="underlined-link">Find your next step <ArrowRight size={16} /></a></div>
      </div>
      <div className="about-values" id="why-us">
        <div className="value-card value-image"><Image src="/adventutorial-learning.png" alt="A joyful moment of learning together" fill sizes="(max-width: 760px) 90vw, 30vw" className="value-photo" /><div className="image-badge"><span className="badge-star">✳</span><span>Little moments.<br />Lasting growth.</span></div></div>
        <div className="value-card value-paper"><span className="card-index">01 / PERSONALIZED CARE</span><div className="value-symbol lilac-symbol"><Heart size={20} /></div><h3>Made for your child</h3><p>One-on-one attention that adapts to their pace, strengths, and goals.</p><span className="card-scribble" aria-hidden="true">✳</span></div>
        <div className="value-card value-green"><span className="card-index">02 / GROW WITH CONFIDENCE</span><div className="value-symbol green-symbol"><Sparkles size={19} /></div><h3>Progress worth celebrating</h3><p>We make room for questions, small wins, and the joy of figuring it out.</p><span className="value-footer">A LITTLE BRAVER, EVERY DAY <ArrowRight size={14} /></span></div>
      </div>
    </section>
  )
}

function Programs() {
  return (
    <section className="programs section-shell" id="programs">
      <div className="section-kicker"><span>02</span><span className="kicker-line" /> HOW WE CAN HELP</div>
      <div className="programs-heading"><div><h2>Good things happen<br />when learning <span>clicks.</span></h2><p>Find the kind of support that feels right for your learner.</p></div><a className="button button-dark programs-cta" href="tel:+639543365987">Ask us about lessons <ArrowRight size={16} /></a></div>
      <div className="program-grid">{programs.map(({ number, icon: Icon, title, description, tone }) => <article className={`program-card ${tone}`} key={number}><div className="program-card-top"><span className="program-number">{number} / 03</span><span className="program-icon"><Icon size={20} strokeWidth={1.8} /></span></div><div><h3>{title}</h3><p>{description}</p></div><a className="program-link" href="tel:+639543365987" aria-label={`Ask about ${title}`}>Explore this program <span><ArrowRight size={16} /></span></a></article>)}</div>
    </section>
  )
}

function FinalCta() {
  return (
    <section className="final-cta section-shell" id="contact"><div className="cta-deco" aria-hidden="true">✳</div><div className="section-kicker cta-kicker"><span>03</span><span className="kicker-line" /> READY WHEN YOU ARE</div><div className="final-cta-content"><h2>The next chapter<br />starts <span>with a hello.</span></h2><p>Tell us what your child needs. We&apos;ll help you find a good place to begin.</p><a className="button button-lime" href="mailto:adventutoriallearningcenter10@gmail.com?subject=Learning%20inquiry">Get in touch <ArrowRight size={17} /></a></div><div className="cta-contact"><span>CALL OR TEXT</span><a href="tel:+639543365987">0954 336 5987</a><span>OR EMAIL</span><a href="mailto:adventutoriallearningcenter10@gmail.com">adventutoriallearningcenter10<br className="desktop-break" />@gmail.com</a></div></section>
  )
}

function Footer() {
  return <footer className="site-footer"><Brand /><span>Little steps. Bright futures.</span><span>© {new Date().getFullYear()} Adventutorial Learning Center · Butuan City</span></footer>
}

export default function AdventutorialSite() {
  return <><Header /><main><Hero /><CommunityStrip /><About /><Programs /><FinalCta /></main><Footer /></>
}
